<?php
    
    ini_set("session.save_path", "appSessionData");
    
    session_start(); 
    
    include('database_conn.php');
    
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <link rel="stylesheet" href="//code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css" />
        <link href="http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet" />
        <script type="text/javascript" src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <script type=text/javascript src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<script type="text/javascript" src="//code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
        <script type="text/javascript">
            //Function to validate form fields
            //Note that AddressLine3 and AddressLine4 are not included as not everyone has or fills out the optional address lines.
            function validateFormFields(){
                'use strict';
                
                //Passing ID as parameter not functioning at all, passes the ID name of the form itself as a paramter to getElementById
                var form = document.getElementById("details");
                
                //Uses the form name attributes in order to obtain their value.
                if(form.forename.value == "") {
                    alert("Form cannot be submitted if forename is blank!");
                    
                    form.forename.focus();
                    
                    return false;
                    
                }
                else if(form.surname.value == "") {
                    alert("Form cannot be submitted if surname is blank!");

                    form.surname.focus();
                    
                    return false;
                }
                else if(form.addressLine1.value == "") {
                    alert("Form cannot be submitted if Address Line 1 is blank!");

                    form.addressLine1.focus();
                    
                    return false;
                }
                else if(form.addressLine2.value == "") {
                    alert("Form cannot be submitted if Address Line 2 is blank!");

                    form.addressLine2.focus();
                    
                    return false;
                }
                else if(form.postcode.value == "") {
                    alert("Form cannot be submitted if postcode is blank!");

                    form.postcode.focus();
                    
                    return false;
                }
                else {
                    return true;
                }
            }
        </script>
    </head>
    <body>
        <div data-role="header" data-position="fixed">
            <h1>NE Foods LTD</h1>
        </div>
        
        <div class="orderSummary" data-role="header">
                <h2>Order Summary</h2>
        </div>
        
        <div class="orderDetails" >
            <label>This is the price of your order! Press enter your details to proceed to checkout.</label>        
                    <?php

                        $total = $_REQUEST['total'] ? $_REQUEST['total'] : null;

                        echo "<label><strong>Total Order Price: $total</strong></label>
                              <form method='post' id='details' onsubmit='return validateFormFields()' action='OrderDetails.php?total=$total'>
                                <input type='text' name='forename' placeholder='Please enter your forename...'/>
                                <input type='text' name='surname' placeholder='Please enter your surname...'/>
                                <input type='text' name='addressLine1' placeholder='Please enter the first line of your address...'/>
                                <input type='text' name='addressLine2' placeholder='Please enter the second line of your address...'/>
                                <input type='text' name='addressLine3' placeholder='Please enter the third line of your address...'/>
                                <input type='text' name='addressLine4' placeholder='Please enter the fourth line of your address...'/>
                                <input type='text' name='postcode' placeholder='Please enter your postcode...'/>
                                <input type='submit' value='Add Order'/></form>";
                    ?>  
            </div>
        
            <div id="navigation" data-role="footer" data-position="fixed"> 
                <form method="post" action="logout.php">
                    <input type="submit" value="Logout" />
                </form>

                <div data-role="navbar">
                        <ul>
                            <li><a href="reviews.html">Reviews</a></li>
                            <li><a href="info.html">Info</a></li>
                            <li><a href="extras.php">Extras</a></li>
                        </ul>
                </div>
            </div>
    </body>
</html>
