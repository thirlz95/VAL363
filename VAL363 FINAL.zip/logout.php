<?php

    ini_set("session.save_path", "appSessionData");
    
    session_start(); 
    
    unset($_SESSION['user']);
    unset($_SESSION['logged-in']);
    session_destroy();

    header("Location: index.php");
    exit;
?>