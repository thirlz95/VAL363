<?php
    
    ini_set("session.save_path", "appSessionData");
    
    session_start(); 
    
    include('database_conn.php');
    
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="stylesheet" type="text/css" href="styles.css" />
        <link rel="stylesheet" href="//code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css" />
        <!-- This link is used in order to take advantage of the progress bar in order to display feedback to the user -->
        <link href="http://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css" rel="stylesheet" />
        <script type="text/javascript" src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <script type=text/javascript src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<script type="text/javascript" src="//code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
        <script type="text/javascript" src="Launchpad.js"></script>
        <script type="text/javascript">
            function orderPrice(name) {
                var selectedItem = document.getElementsByName(name);
                
                var total = 0;
                
                for(var i = 0; i < selectedItem.length; i++) {
                    if(selectedItem[i].checked) {
                        total += parseFloat(selectedItem[i].title);
                    }
                }
                
                document.getElementById("total").value = "" + total.toFixed(2);
            }
            
            function toggleAddOrderVisibility() {       
                //Gets the elements based on particular properties and assign them 
                //to these variables.
                var cart = document.getElementById("addToOrder");
                var checkbox = document.getElementsByName("food[]");
                
                //Initialise variable i with value of 0, as long as i is less than the length of the checkbox element length, increment the value by 1.
                for(var i = 0; i < checkbox.length; i++) {
                    //If the submit button status is equal to 1 and at least 1 checkbox element is checked{
                    //enable the submit button.
                    //}
                    //Else { 
                    //submit is disabled.
                    //}
                    
                    if(checkbox[i].checked == true) {
                        cart.style.visibility = 'visible';
                        return;
                    }
                    else {
                        cart.style.visibility = 'hidden';
                    }
                }
            }
        </script>
    </head>
    <body>
        <div data-role="header" data-position="fixed">
            <h1>NE Foods LTD</h1>
        </div>
        
        <div class="title" data-role="header">
                <h2>Select Category</h2>
        </div>
        
        <form method="post" id="options">
            <select name="selected" id="type">
                <option value="Please Select">Please Select</option>
                <?php

                        $sqlCategory = 'SELECT DISTINCT app_restaurant_category.catName, 
                                        app_restaurant_name.catID 
                                        FROM app_restaurant_category 
                                        INNER JOIN app_restaurant_name 
                                        ON app_restaurant_name.catID = app_restaurant_category.catID';

                        $results = mysqli_query($conn, $sqlCategory) or die(mysqli_error($conn));

                        while ($restaurantType = mysqli_fetch_assoc($results)) {
                           $catID = $restaurantType['catID'];
                            echo '<option value="'.$catID.'">'.$restaurantType['catName'].'</option>';
                        }
                        
                        mysqli_free_result($results);//Freeing up memory resources. 
                        mysqli_close($conn);

                ?>
            </select>
            <input type="submit" id="submit" value="Submit"/>
        </form>
        
        <div id="progressbar">
            <div class="progress-label">
                Loading...
            </div>
        </div>
        
        <div class="restaurant" data-role="header">
            <h1>
                Restaurant
            </h1>
        </div>
        
        <div class="restaurant">
            <label id="displayRestaurant">Select from the wonderful assortment of Restaurants that are available in the following category: <?php echo $restaurantType['catName']; ?></label>
            <div id="showRestaurant"></div>
        </div>
        
        <section>
            <div class="addItems">
                <h2>
                        Add to Basket
                </h2>
                    <div id="availableRestaurants">  
                    </div>
            </div>
            
        </section>
                <div id="navigation" data-role="footer" data-position="fixed"> 
                    
                    <form method="post" action="logout.php">
                        <input type="submit" value="Logout" />
                    </form>
                        
                    <div id="addToOrder" style="visibility: hidden">
                        <form method="post" id="add" action="OrderSummary.php">
                            <label><strong>Total: </strong></label>
                                <input type="text" name="total" id="total" value="0.00" size="10" readonly="readonly" />
                            <input type="submit" value="Add To Cart" />
                        </form>
                    </div>
                    
                    <div data-role="navbar">
                        <ul>
                            <li><a href="reviews.html">Reviews</a></li>
                            <li><a href="info.html">Info</a></li>
                            <li><a href="extras.php">Extras</a></li>
                        </ul>
                    </div>
                    
                </div>
    </body>
</html>
