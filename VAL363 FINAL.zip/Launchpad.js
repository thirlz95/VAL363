$(document).ready(function() {
    //Animations to be called once page is ready.
    
    $('#loginPage').show('slide');
    $('#options').show('clip');
    $('.title').slideDown();
    
    $('#options').submit(function(e) {
        
        //Assigns the select element with the ID of type to a variable.
        var type = $('#type');
        
        //Using the newly assigned type variable in order to determine it's value.
        //If value is Please Select or null, display an alert to the user and prevent the default action of the form submission from going ahead.
        //Else, perform as per normal application behaviour.
        if(type.val() == "Please Select" || null) {
            alert("Please select an option!");
            //Assigns parameter passed into function when clicked in order to only stop the default action performing.
            e.preventDefault();
        } else {
            $('#options').hide('blind');
            $('.title').hide('blind');
            $('.login').css('display', 'inline-block');
            $('.progress-label').css('display', 'block');
            
            e.preventDefault();
            
            //Assignment of the progressbar div ID and the progress-label div class to variables.
            //These will be used to refer to these elements when calculating the value of the progress bar when invoked.
            var barProgress = $('#progressbar');
            var progressLabel = $('.progress-label');
            
            //Creating the functionality for the progressbar element.
            //Initial value is set to false. 
            //However, 2 functions (change: when progressbar is not complete, complete: when progressbar job is done) are used to feedback status to the user.
            //Progress function begins the process of initialising the current value (or if it's 0) as it's starting state and then invoking further behaviour once value reaches 100.
            $('#progressbar').progressbar({
                value: false,
                change: function() { 
                    progressLabel.text(barProgress.progressbar('value') + '%');
                },
                complete: function() {
                    progressLabel.text('Loading Completed!');
                }
            });
            function progress() {
                var barValue = barProgress.progressbar('value') || 0;
                barProgress.progressbar('value', barValue + 1);
                if(barValue < 99) {
                     setTimeout(progress, 100);
                }
                else if(barValue = 100) {
                    
                    //Animations for when barvalue = 100.
                    $('#progressbar').hide('blind', 1000);
                    $('.restaurant').fadeIn(2000);
                    
                    //Ajax call to append the data retrieved from the getRestaurants.php to the UI, without having to refresh the page.
                    $('#displayRestaurant').text(function () {
                        $.ajax({
                            method: "get",
                            url: "getRestaurants.php?selected=" + type.val() 
                        })
                        .done(function (results) {
                                var restaurants = $('#showRestaurant').append('<div/>');
                                window.console && console.log(status + '\n'+results);
                                $(results).each(function () {
                                    $(restaurants).html(results);
                                     $('.restaurant').fadeIn(2000);
                                     
                                     //Message to be displayed based on time of day.
                                        $('.restaurant').ready(function()
                                        {
                                            var currentTime = new Date();
                                            var hour = currentTime.getHours();
                                            var displayMessage;
                                            if(hour >= 11) {
                                                 displayMessage = "Open";
                                             }
                                            else if(hour = 23) {
                                                 displayMessage = "Closed";
                                            }
                                            return $('#status strong').text(displayMessage);
                                        });
                                         $(".select").click(function(e) {
                                             e.preventDefault();
                                             $('.restaurant').hide('blind');
                                             $('.addItems').fadeIn(1000);
                                             $('#navigation').slideDown('blind');
                                             $('#availableRestaurants').fadeIn(1000);
                                             $("#availableRestaurants").load($('.select').attr("page"), 500).html('#availableRestaurants');
                                         
                                    });
                                });

                            }
                        )
                        .fail(function(textStatus, errorThrown) {
                                 window.console && console.log(textStatus + ': ' + errorThrown);
                            }
                        );
                    });
                }
            }
            setTimeout(progress, 3000);
        }
    });
    
});



