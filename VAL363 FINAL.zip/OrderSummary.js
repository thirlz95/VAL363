$(document).ready(function() {
    $('.orderSummary').slideDown();
    $('.title').slideDown();
    
});
