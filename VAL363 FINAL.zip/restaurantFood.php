<?php
                    
                        include 'database_conn.php';

                        $sql = "SELECT foodID, 
                                foodName, 
                                foodType, 
                                foodPrice,
                                restaurantID
                                FROM app_restaurant_food";

                        //Executes the query and stores the result set of said query, or fail the connection.
                        $foodResults = mysqli_query($conn, $sql) or die (mysqli_error($conn));

                        //while loop used to fetch details for each record from the DB and stores them in variables
                        while($foodRow = mysqli_fetch_assoc($foodResults)) {
                            $foodID = $foodRow['foodID'];
                            $foodName = $foodRow['foodName'];
                            $foodType = $foodRow['foodType'];
                            $foodPrice = $foodRow['foodPrice'];
                            $restID = $foodRow['restaurantID'];
                            
                            //Echo's out each variable and the values they retrieved from the DB
                                echo "<table>
                                        <thead>
                                            <tr>
                                                <br>
                                                    <td><b>Food</b></td>
                                                    <td><b>Type</b></td>
                                                    <td><b>Price</b></td>
                                                    <td><b>Select Item</b></td>
                                                </br>
                                            </tr>
                                        </thead><tr><br>
                                <td>$foodName</td>
                                <td>$foodType</td>
                                <td>$foodPrice</td>
                                <td><input type='checkbox' id='availableFood' onclick='orderPrice(this.name), toggleAddOrderVisibility()' name='food[]' value='{$foodName}' title='{$foodPrice}' /></td>
                            </br></tr></table>";
                        }   

                        mysqli_free_result($foodResults); 
                        mysqli_close($conn); 
                        

