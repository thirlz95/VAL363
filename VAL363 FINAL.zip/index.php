<?php
    
    ini_set("session.save_path", "appSessionData");
    
    session_start(); 
    
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
        
        <link rel="stylesheet" type="text/css" href="styles.css">
        <link rel="stylesheet" href="//code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css" />
        <script type="text/javascript" src="//code.jquery.com/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="//code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
        <script type="text/javascript" src="Launchpad.js"></script>
        
    </head>
    <body>
        <div id="loginPage">
            <div data-role="header">
                <h1>Hungry Horse</h1>
            </div>

            <section>
                <div id="loginField">
                    <form method="post" id="loginForm" action="#">
                        <label>Username</label>
                        <input type="text" id="username" placeholder="Enter your username..."/>
                        <label>Password</label>
                        <input type="password" id="password" placeholder="Enter your password..."/>
                        <input type="submit" id ="login" value="Login">
                            <div id="navigation" data-role="footer" data-position="fixed"> 
                                <form method="post" action="logout.php">
                                    <input type="submit" action="login.php" value="Login">
                                </form>
                                <div data-role="navbar">
                                    <ul>
                                        <li><a href="reviews.html">Reviews</a></li>
                                        <li><a href="info.html">Info</a></li>
                                        <li><a href="c.html">Extras</a></li>
                                        <li><a href="d.html">Summary</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </section>
        </div>
    </body>
</html>
